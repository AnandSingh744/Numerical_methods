"""
PRACTICAL 4: GAUSS-JACOBI METHOD AND GAUSS-SEIDEL METHOD
Solve Ax = b iteratively (A should be diagonally dominant).
Run: python practical_4_gauss_jacobi_seidel.py
"""


def gauss_jacobi(A, b, tol=1e-6, max_iter=100):
    """Every new value is computed using ONLY the values of the previous iteration."""
    n = len(b)
    x = [0.0] * n                         # initial guess (0, 0, ..., 0)

    print("Iter  " + "  ".join(f"{'x' + str(i + 1):>10}" for i in range(n)))
    for k in range(1, max_iter + 1):
        x_new = [0.0] * n
        for i in range(n):
            s = sum(A[i][j] * x[j] for j in range(n) if j != i)
            x_new[i] = (b[i] - s) / A[i][i]
        print(f"{k:>4}  " + "  ".join(f"{v:>10.6f}" for v in x_new))

        if max(abs(x_new[i] - x[i]) for i in range(n)) < tol:
            x = x_new
            break
        x = x_new
    print("Solution by Gauss-Jacobi:", [round(v, 6) for v in x], "\n")
    return x


def gauss_seidel(A, b, tol=1e-6, max_iter=100):
    """Each new value is used IMMEDIATELY in the same iteration (faster than Jacobi)."""
    n = len(b)
    x = [0.0] * n

    print("Iter  " + "  ".join(f"{'x' + str(i + 1):>10}" for i in range(n)))
    for k in range(1, max_iter + 1):
        x_old = x.copy()
        for i in range(n):
            s = sum(A[i][j] * x[j] for j in range(n) if j != i)
            x[i] = (b[i] - s) / A[i][i]
        print(f"{k:>4}  " + "  ".join(f"{v:>10.6f}" for v in x))

        if max(abs(x[i] - x_old[i]) for i in range(n)) < tol:
            break
    print("Solution by Gauss-Seidel:", [round(v, 6) for v in x], "\n")
    return x


if __name__ == "__main__":
    # 10x + y + z = 12,  2x + 10y + z = 13,  2x + 2y + 10z = 14   (answer: 1, 1, 1)
    A = [[10, 1, 1],
         [2, 10, 1],
         [2, 2, 10]]
    b = [12, 13, 14]
    print("10x + y + z = 12\n2x + 10y + z = 13\n2x + 2y + 10z = 14\n")
    print("PRACTICAL 4(a): GAUSS-JACOBI METHOD\n")
    gauss_jacobi(A, b)
    print("PRACTICAL 4(b): GAUSS-SEIDEL METHOD\n")
    gauss_seidel(A, b)
