"""
PRACTICAL 6: TRAPEZOIDAL RULE AND SIMPSON'S RULE (1/3 and 3/8)
Run: python practical_6_trapezoidal_simpson.py
"""

import math


def trapezoidal(f, a, b, n):
    """I = h/2 * [y0 + 2(y1 + y2 + ... + y(n-1)) + yn]"""
    h = (b - a) / n
    s = f(a) + f(b)
    for i in range(1, n):
        s += 2 * f(a + i * h)
    result = h / 2 * s
    print(f"Trapezoidal rule (n = {n})   = {result:.6f}")
    return result


def simpson_13(f, a, b, n):
    """I = h/3 * [y0 + 4(odd terms) + 2(even terms) + yn]   (n must be even)"""
    if n % 2 != 0:
        print("Simpson's 1/3 rule needs an EVEN number of intervals.")
        return None
    h = (b - a) / n
    s = f(a) + f(b)
    for i in range(1, n):
        s += (4 if i % 2 == 1 else 2) * f(a + i * h)
    result = h / 3 * s
    print(f"Simpson's 1/3 rule (n = {n}) = {result:.6f}")
    return result


def simpson_38(f, a, b, n):
    """I = 3h/8 * [y0 + 3(terms not multiple of 3) + 2(multiples of 3) + yn]
       (n must be a multiple of 3)"""
    if n % 3 != 0:
        print("Simpson's 3/8 rule needs n to be a MULTIPLE OF 3.")
        return None
    h = (b - a) / n
    s = f(a) + f(b)
    for i in range(1, n):
        s += (2 if i % 3 == 0 else 3) * f(a + i * h)
    result = 3 * h / 8 * s
    print(f"Simpson's 3/8 rule (n = {n}) = {result:.6f}")
    return result


# Example: integral of 1/(1+x^2) from 0 to 1 = pi/4 = 0.785398
def f(x):
    return 1 / (1 + x ** 2)


if __name__ == "__main__":
    a, b, n = 0, 1, 6
    print("PRACTICAL 6: NUMERICAL INTEGRATION   integral of 1/(1+x^2) from 0 to 1\n")
    trapezoidal(f, a, b, n)
    simpson_13(f, a, b, n)
    simpson_38(f, a, b, n)
    print(f"Exact value (pi/4)        = {math.pi / 4:.6f}")
