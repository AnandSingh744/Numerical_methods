"""
PRACTICAL 1: BISECTION METHOD
Find a root of f(x) = 0 in [a, b], where f(a) and f(b) have opposite signs.
Run: python practical_1_bisection.py
"""


def bisection(f, a, b, tol=1e-6, max_iter=100):
    """Find a root of f in [a, b]. f(a) and f(b) must have opposite signs."""
    if f(a) * f(b) > 0:
        print("f(a) and f(b) must have opposite signs. Choose another interval.")
        return None

    print(f"{'Iter':>4} {'a':>12} {'b':>12} {'c':>12} {'f(c)':>14}")
    c = a
    for i in range(1, max_iter + 1):
        c = (a + b) / 2                      # mid point
        fc = f(c)
        print(f"{i:>4} {a:>12.6f} {b:>12.6f} {c:>12.6f} {fc:>14.6e}")

        if abs(fc) < tol or (b - a) / 2 < tol:
            break
        if f(a) * fc < 0:                    # root lies in [a, c]
            b = c
        else:                                # root lies in [c, b]
            a = c
    print(f"Root by Bisection method = {c:.6f}\n")
    return c


# Example: f(x) = x^3 - x - 2   (root ~ 1.521380)
def f(x):
    return x ** 3 - x - 2


if __name__ == "__main__":
    print("PRACTICAL 1: BISECTION METHOD   f(x) = x^3 - x - 2,  [1, 2]\n")
    bisection(f, 1, 2)
