"""
PRACTICAL 5: LAGRANGE INTERPOLATION AND NEWTON INTERPOLATION
(Newton's divided difference form - works for equal or unequal spacing)
Run: python practical_5_lagrange_newton_interpolation.py
"""


def lagrange_interpolation(xs, ys, xp):
    """P(x) = sum of y_i * L_i(x), where L_i(x) = product of (x - x_j)/(x_i - x_j), j != i"""
    n = len(xs)
    result = 0.0
    for i in range(n):
        L = 1.0
        for j in range(n):
            if j != i:
                L *= (xp - xs[j]) / (xs[i] - xs[j])
        print(f"L{i}({xp}) = {L:.6f}")
        result += ys[i] * L
    print(f"Value at x = {xp} by Lagrange interpolation = {result:.6f}\n")
    return result


def newton_interpolation(xs, ys, xp):
    """Builds the divided difference table, then
       P(x) = f[x0] + f[x0,x1](x-x0) + f[x0,x1,x2](x-x0)(x-x1) + ..."""
    n = len(xs)
    table = [[0.0] * n for _ in range(n)]
    for i in range(n):
        table[i][0] = ys[i]
    for j in range(1, n):
        for i in range(n - j):
            table[i][j] = (table[i + 1][j - 1] - table[i][j - 1]) / (xs[i + j] - xs[i])

    print("Divided Difference Table:")
    for i in range(n):
        row = f"{xs[i]:>8.3f} | " + " ".join(f"{table[i][j]:>10.4f}" for j in range(n - i))
        print(row)

    result = table[0][0]
    term = 1.0
    for j in range(1, n):
        term *= (xp - xs[j - 1])
        result += table[0][j] * term
    print(f"Value at x = {xp} by Newton interpolation = {result:.6f}\n")
    return result


if __name__ == "__main__":
    # Data from y = x^3 + 1 ;  exact value at 1.5 is 4.375
    xs = [0, 1, 2, 3]
    ys = [1, 2, 9, 28]
    xp = 1.5
    print("x :", xs, "\ny :", ys, f"\nFind y at x = {xp}\n")
    print("PRACTICAL 5(a): LAGRANGE INTERPOLATION\n")
    lagrange_interpolation(xs, ys, xp)
    print("PRACTICAL 5(b): NEWTON'S DIVIDED DIFFERENCE INTERPOLATION\n")
    newton_interpolation(xs, ys, xp)
