"""
PRACTICAL 7: EULER'S METHOD AND RUNGE-KUTTA METHODS (RK2, RK4)
for first order initial value problems  dy/dx = f(x, y),  y(x0) = y0
Run: python practical_7_euler_runge_kutta.py
"""

import math


def euler(f, x0, y0, h, xn):
    """y(n+1) = y(n) + h * f(x(n), y(n))"""
    print(f"{'x':>8} {'y (Euler)':>14}")
    x, y = x0, y0
    print(f"{x:>8.3f} {y:>14.6f}")
    while x < xn - 1e-12:
        y = y + h * f(x, y)
        x = x + h
        print(f"{x:>8.3f} {y:>14.6f}")
    print(f"y({xn}) by Euler's method = {y:.6f}\n")
    return y


def runge_kutta_2(f, x0, y0, h, xn):
    """k1 = h f(x, y);  k2 = h f(x + h, y + k1);  y(n+1) = y(n) + (k1 + k2)/2"""
    print(f"{'x':>8} {'y (RK2)':>14}")
    x, y = x0, y0
    print(f"{x:>8.3f} {y:>14.6f}")
    while x < xn - 1e-12:
        k1 = h * f(x, y)
        k2 = h * f(x + h, y + k1)
        y = y + (k1 + k2) / 2
        x = x + h
        print(f"{x:>8.3f} {y:>14.6f}")
    print(f"y({xn}) by RK2 method = {y:.6f}\n")
    return y


def runge_kutta_4(f, x0, y0, h, xn):
    """k1 = h f(x, y)
       k2 = h f(x + h/2, y + k1/2)
       k3 = h f(x + h/2, y + k2/2)
       k4 = h f(x + h,   y + k3)
       y(n+1) = y(n) + (k1 + 2k2 + 2k3 + k4)/6"""
    print(f"{'x':>8} {'k1':>10} {'k2':>10} {'k3':>10} {'k4':>10} {'y (RK4)':>12}")
    x, y = x0, y0
    print(f"{x:>8.3f} {'':>10} {'':>10} {'':>10} {'':>10} {y:>12.6f}")
    while x < xn - 1e-12:
        k1 = h * f(x, y)
        k2 = h * f(x + h / 2, y + k1 / 2)
        k3 = h * f(x + h / 2, y + k2 / 2)
        k4 = h * f(x + h, y + k3)
        y = y + (k1 + 2 * k2 + 2 * k3 + k4) / 6
        x = x + h
        print(f"{x:>8.3f} {k1:>10.6f} {k2:>10.6f} {k3:>10.6f} {k4:>10.6f} {y:>12.6f}")
    print(f"y({xn}) by RK4 method = {y:.6f}\n")
    return y


# Example: dy/dx = x + y,  y(0) = 1.  Exact solution: y = 2e^x - x - 1
def f(x, y):
    return x + y


if __name__ == "__main__":
    x0, y0, h, xn = 0, 1, 0.1, 0.5
    print("PRACTICAL 7(a): EULER'S METHOD   dy/dx = x + y,  y(0) = 1,  h = 0.1\n")
    euler(f, x0, y0, h, xn)
    print("PRACTICAL 7(b): RUNGE-KUTTA 2nd ORDER METHOD\n")
    runge_kutta_2(f, x0, y0, h, xn)
    print("PRACTICAL 7(c): RUNGE-KUTTA 4th ORDER METHOD\n")
    runge_kutta_4(f, x0, y0, h, xn)
    print(f"Exact value y(0.5) = {2 * math.exp(0.5) - 0.5 - 1:.6f}")
