"""
PRACTICAL 2: SECANT METHOD AND REGULA-FALSI METHOD
Run: python practical_2_secant_regula_falsi.py
"""


def secant(f, x0, x1, tol=1e-6, max_iter=100):
    """x2 = x1 - f(x1) * (x1 - x0) / (f(x1) - f(x0))"""
    print(f"{'Iter':>4} {'x0':>12} {'x1':>12} {'x2':>12} {'f(x2)':>14}")
    x2 = x1
    for i in range(1, max_iter + 1):
        if f(x1) - f(x0) == 0:
            print("Division by zero. Method fails.")
            return None
        x2 = x1 - f(x1) * (x1 - x0) / (f(x1) - f(x0))
        print(f"{i:>4} {x0:>12.6f} {x1:>12.6f} {x2:>12.6f} {f(x2):>14.6e}")

        if abs(x2 - x1) < tol:
            break
        x0, x1 = x1, x2
    print(f"Root by Secant method = {x2:.6f}\n")
    return x2


def regula_falsi(f, a, b, tol=1e-6, max_iter=100):
    """c = (a*f(b) - b*f(a)) / (f(b) - f(a)); root is always kept bracketed."""
    if f(a) * f(b) > 0:
        print("f(a) and f(b) must have opposite signs. Choose another interval.")
        return None

    print(f"{'Iter':>4} {'a':>12} {'b':>12} {'c':>12} {'f(c)':>14}")
    c_old = a
    c = a
    for i in range(1, max_iter + 1):
        c = (a * f(b) - b * f(a)) / (f(b) - f(a))
        fc = f(c)
        print(f"{i:>4} {a:>12.6f} {b:>12.6f} {c:>12.6f} {fc:>14.6e}")

        if abs(fc) < tol or abs(c - c_old) < tol:
            break
        if f(a) * fc < 0:
            b = c
        else:
            a = c
        c_old = c
    print(f"Root by Regula-Falsi method = {c:.6f}\n")
    return c


# Example: f(x) = x^3 - x - 2   (root ~ 1.521380)
def f(x):
    return x ** 3 - x - 2


if __name__ == "__main__":
    print("PRACTICAL 2(a): SECANT METHOD   f(x) = x^3 - x - 2,  x0 = 1, x1 = 2\n")
    secant(f, 1, 2)
    print("PRACTICAL 2(b): REGULA-FALSI METHOD   f(x) = x^3 - x - 2,  [1, 2]\n")
    regula_falsi(f, 1, 2)
