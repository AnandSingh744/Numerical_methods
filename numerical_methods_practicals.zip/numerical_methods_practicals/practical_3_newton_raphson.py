"""
PRACTICAL 3: NEWTON-RAPHSON METHOD
x(n+1) = x(n) - f(x(n)) / f'(x(n))
Run: python practical_3_newton_raphson.py
"""


def newton_raphson(f, df, x0, tol=1e-6, max_iter=100):
    """x(n+1) = x(n) - f(x(n)) / f'(x(n))"""
    print(f"{'Iter':>4} {'x_n':>12} {'f(x_n)':>14} {'x_(n+1)':>12}")
    x1 = x0
    for i in range(1, max_iter + 1):
        if df(x0) == 0:
            print("Derivative became zero. Method fails.")
            return None
        x1 = x0 - f(x0) / df(x0)
        print(f"{i:>4} {x0:>12.6f} {f(x0):>14.6e} {x1:>12.6f}")

        if abs(x1 - x0) < tol:
            break
        x0 = x1
    print(f"Root by Newton-Raphson method = {x1:.6f}\n")
    return x1


# Example: f(x) = x^3 - x - 2,  f'(x) = 3x^2 - 1   (root ~ 1.521380)
def f(x):
    return x ** 3 - x - 2


def df(x):
    return 3 * x ** 2 - 1


if __name__ == "__main__":
    print("PRACTICAL 3: NEWTON-RAPHSON METHOD   f(x) = x^3 - x - 2,  x0 = 1.5\n")
    newton_raphson(f, df, 1.5)
